package com.example.laborator1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickRegister(View view){
        TextView credentials = findViewById(R.id.Credentials);
        TextView credentials2 = findViewById(R.id.credentials2);
        EditText FirstName = findViewById(R.id.FirstName);
        EditText LastName = findViewById(R.id.LastName);
        EditText Email = findViewById(R.id.Email);
        credentials.setText("Thanks, " + FirstName.getText().toString() + ", " + LastName.getText().toString() + " for a freshly account" + ". ");
        credentials2.setText("Your email is: " + Email.getText().toString());
    }

    public void onClickShowToast(View view){
        Context context = getApplicationContext();
        CharSequence text = "Just one more minute, please!";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
}
